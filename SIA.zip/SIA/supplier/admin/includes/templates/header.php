<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title><?php echo getTitle() ?></title> <!-- getTitle() function is declared in eCommerce\admin\includes\functions\functions.php -->
        <link rel="stylesheet" href="<?php echo $css; ?>bootstrap.min.css">      <!-- $css variable is declared in eCommerce\admin\init.php -->
        <link rel="stylesheet" href="<?php echo $css; ?>font-awesome.min.css">   <!-- $css variable is declared in eCommerce\admin\init.php -->
        <link rel="stylesheet" href="<?php echo $css; ?>jquery-ui.min.css">      <!-- $css variable is declared in eCommerce\admin\init.php -->
        <link rel="stylesheet" href="<?php echo $css; ?>jquery.selectBoxIt.css"> <!-- $css variable is declared in eCommerce\admin\init.php -->
        <link rel="stylesheet" href="<?php echo $css; ?>backend.css">            <!-- $css variable is declared in eCommerce\admin\init.php -->
    </head>
    <body>