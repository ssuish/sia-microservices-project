        <div class="footer">
            
        </div>

        <script src="<?php echo $js; ?>jquery-3.3.1.min.js"></script>       <!-- $js variable is declared in eCommerce\init.php -->
        <script src="<?php echo $js; ?>jquery-ui.min.js"></script>          <!-- $js variable is declared in eCommerce\init.php -->
        <script src="<?php echo $js; ?>bootstrap.min.js"></script>          <!-- $js variable is declared in eCommerce\init.php -->
        <script src="<?php echo $js; ?>jquery.selectBoxIt.min.js"></script> <!-- $js variable is declared in eCommerce\init.php -->
        <script src="<?php echo $js; ?>front.js"></script>                  <!-- $js variable is declared in eCommerce\init.php -->
    </body>
</html>